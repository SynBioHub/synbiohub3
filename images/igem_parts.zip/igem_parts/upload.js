

fs = require('fs');
request = require('request');
path = require('path');
function walk(currentDirPath, callback) {
    fs.readdirSync(currentDirPath).forEach(function (name) {
        var filePath = path.join(currentDirPath, name);
        var stat = fs.statSync(filePath);
        if (stat.isFile()) {
            callback(filePath, stat);
        } else if (stat.isDirectory()) {
            walk(filePath, callback);
        }
    });
}

var files = [];

walk('./out', function (filename) {

    //console.log(filename)

    files.push(filename);
});

console.log(`Found ${files.length} files under ./out`);
if (files.length === 0) {
  console.error('No files found. Is ./out correct relative to where you run node?');
  process.exit(1);
}

//console.log(JSON.stringify(files, null, 2))

//var i = parseInt(fs.readFileSync('last') + '');
var i = 0;

function next() {
    if (i >= files.length) {
        console.log(`Done. Uploaded ${files.length} files.`);
        return;
    }
    var filename = files[i];
    i++;
    if (!filename) {
        console.error(`Invalid filename at index ${i - 1}`, files.slice(0, 10));
        return;
    }
    console.log('reading file ' + filename)

    request({
        method: 'POST',
        //url: 'http://biocad.ncl.ac.uk:3030/igem/upload',
        url: 'http://localhost:8890/sparql-graph-crud-auth/?graph-uri=https://synbiohub.org/public',
        //url: 'http://synbiohub.org:8080/openrdf-sesame/repositories/synbiohub/statements',
        auth: {
            user: 'dba',
            pass: 'dba',
            //            pass: 'nyr-Dbt-roh-QW3',
            sendImmediately: false
        },
        /*qs: {
            'context': 'null'
        },*/
        headers: {
            //'Content-Type': 'multipart/form-data'
            'Content-Type': 'application/rdf+xml'
        },
        //formData: {
        //file: fs.createReadStream(filename)
        //}
        body: fs.readFileSync(filename) + ''
    }, function (err, response, body) {
        var statusCode = response ? response.statusCode : 'no response';

        if (err) {
            console.error('failed ' + filename + ': ' + err.message);
        } else {
            console.log('submitted ' + filename + ' with status ' + statusCode);
            if (body) console.log(body);
            fs.writeFileSync('last', i + '');
        }

        next();

        //callback(null, body);
    });
}

next();



